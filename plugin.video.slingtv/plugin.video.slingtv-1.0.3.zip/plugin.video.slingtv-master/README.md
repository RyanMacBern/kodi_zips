# plugin.video.slingtv
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/0dfe103145134ebcaceeeb896090fa5f)](https://www.codacy.com?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Lunatixz/plugin.video.slingtv&amp;utm_campaign=Badge_Grade)
